package com.udacity.webcrawler;

import com.udacity.webcrawler.json.CrawlResult;
import com.udacity.webcrawler.parser.PageParser;
import com.udacity.webcrawler.parser.PageParserFactory;

import javax.inject.Inject;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;
import java.util.regex.Pattern;

/**
 * A concrete implementation of {@link WebCrawler} that runs multiple threads on a
 * {@link ForkJoinPool} to fetch and process multiple web pages in parallel.
 */
final class ParallelWebCrawler implements WebCrawler {
    private final Clock clock;
    private final PageParserFactory parserFactory;
    private final Duration timeout;
    private final int popularWordCount;
    private final int maxDepth;
    private final List<Pattern> ignoredUrls;
    private final ForkJoinPool pool;

    /**
     * Constructs a {@link ParallelWebCrawler} with the provided dependencies.
     */
    @Inject
    ParallelWebCrawler(
            Clock clock,
            PageParserFactory parserFactory,
            @Timeout Duration timeout,
            @PopularWordCount int popularWordCount,
            @MaxDepth int maxDepth,
            @TargetParallelism int threadCount,
            @IgnoredUrls List<Pattern> ignoredUrls) {
        this.clock = clock;
        this.parserFactory = parserFactory;
        this.timeout = timeout;
        this.popularWordCount = popularWordCount;
        this.maxDepth = maxDepth;
        this.ignoredUrls = ignoredUrls;
        // Respect both requested threads and available processors
        this.pool = new ForkJoinPool(Math.min(threadCount, getMaxParallelism()));
    }

    /**
     * Returns the maximum parallelism based on available processors.
     */
    @Override
    public int getMaxParallelism() {
        return Math.max(2, Runtime.getRuntime().availableProcessors());
    }

    /**
     * Crawls the web starting from the given URLs.
     *
     * @param startingUrls the list of URLs to start crawling from
     * @return a {@link CrawlResult} containing the word counts and URLs visited
     */
    @Override
    public CrawlResult crawl(List<String> startingUrls) {
        Instant deadline = clock.instant().plus(timeout);
        Map<String, Integer> counts = new HashMap<>();
        Set<String> visitedUrls = Collections.synchronizedSet(new HashSet<>());

        for (String url : startingUrls) {
            pool.invoke(new CrawlTask(url, deadline, maxDepth, counts, visitedUrls));
        }

        return new CrawlResult.Builder()
                .setWordCounts(counts.isEmpty() ? counts : WordCounts.sort(counts, popularWordCount))
                .setUrlsVisited(visitedUrls.size())
                .build();
    }

    /**
     * A {@link RecursiveAction} task that crawls a single URL and recursively schedules
     * subtasks for links found on the page.
     */
    private class CrawlTask extends RecursiveAction {
        private final String url;
        private final Instant deadline;
        private final int depth;
        private final Map<String, Integer> counts;
        private final Set<String> visitedUrls;

        CrawlTask(
                String url,
                Instant deadline,
                int depth,
                Map<String, Integer> counts,
                Set<String> visitedUrls) {
            this.url = url;
            this.deadline = deadline;
            this.depth = depth;
            this.counts = counts;
            this.visitedUrls = visitedUrls;
        }

        @Override
        protected void compute() {
            if (depth == 0 || clock.instant().isAfter(deadline)) {
                return;
            }

            for (Pattern pattern : ignoredUrls) {
                if (pattern.matcher(url).matches()) {
                    return;
                }
            }

            if (!visitedUrls.add(url)) {
                return;
            }

            PageParser.Result result = parserFactory.get(url).parse();

            synchronized (counts) {
                for (Map.Entry<String, Integer> e : result.getWordCounts().entrySet()) {
                    counts.merge(e.getKey(), e.getValue(), Integer::sum);
                }
            }

            List<CrawlTask> subtasks = new ArrayList<>();
            for (String link : result.getLinks()) {
                subtasks.add(new CrawlTask(link, deadline, depth - 1, counts, visitedUrls));
            }
            invokeAll(subtasks);
        }
    }
}
