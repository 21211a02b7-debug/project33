package com.udacity.webcrawler;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Utility class that sorts the map of word counts.
 */
final class WordCounts {

    /**
     * Given an unsorted map of word counts, returns a new map whose word counts are sorted according
     * to the desired ranking rules, and includes only the top
     * {@param popularWordCount} words and counts.
     *
     * This version is implemented using only the Stream API and lambdas/method references.
     *
     * @param wordCounts       the unsorted map of word counts.
     * @param popularWordCount the number of popular words to include in the result map.
     * @return a map containing the top {@param popularWordCount} words and counts in the right order.
     */
    static Map<String, Integer> sort(Map<String, Integer> wordCounts, int popularWordCount) {
        return wordCounts.entrySet()
                .stream()
                .sorted((e1, e2) -> {
                    int freqCompare = Integer.compare(e2.getValue(), e1.getValue());
                    if (freqCompare != 0) return freqCompare;
                    int lengthCompare = Integer.compare(e2.getKey().length(), e1.getKey().length());
                    if (lengthCompare != 0) return lengthCompare;
                    return e1.getKey().compareTo(e2.getKey());
                })
                .limit(popularWordCount)
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        Map.Entry::getValue,
                        (existing, replacement) -> existing,
                        LinkedHashMap::new
                ));
    }

    private WordCounts() {
        // This class cannot be instantiated
    }
}
