package com.udacity.webcrawler.json;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.Reader;
import java.nio.file.Path;
import java.util.Objects;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/**
 * A static utility class that loads a JSON configuration file.
 */
public final class ConfigurationLoader {

    private final Path path;

    /**
     * Create a {@link ConfigurationLoader} that loads configuration from the given {@link Path}.
     */
    public ConfigurationLoader(Path path) {
        this.path = Objects.requireNonNull(path);
    }

    /**
     * Loads configuration from this {@link ConfigurationLoader}'s path
     *
     * @return the loaded {@link CrawlerConfiguration}.
     */
    public CrawlerConfiguration load() {
        // Load the JSON file from path using a Reader
        try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            return read(reader);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load configuration file: " + path, e);
        }
    }

    /**
     * Loads crawler configuration from the given reader.
     *
     * @param reader a Reader pointing to a JSON string that contains crawler configuration.
     * @return a crawler configuration
     */
    public static CrawlerConfiguration read(Reader reader) {
        // Ensure reader is not null
        Objects.requireNonNull(reader);
        try {
            ObjectMapper mapper = new ObjectMapper();
            // Prevent Jackson from closing the reader automatically
            mapper.disable(JsonParser.Feature.AUTO_CLOSE_SOURCE);
            // Deserialize JSON into CrawlerConfiguration using the Builder
            return mapper.readValue(reader, CrawlerConfiguration.class);
        } catch (IOException e) {
            throw new RuntimeException("Failed to read configuration", e);
        }
    }
}
