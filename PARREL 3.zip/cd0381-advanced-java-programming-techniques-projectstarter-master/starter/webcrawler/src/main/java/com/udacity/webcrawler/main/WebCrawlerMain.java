package com.udacity.webcrawler.main;

import com.google.inject.Guice;
import com.udacity.webcrawler.WebCrawler;
import com.udacity.webcrawler.WebCrawlerModule;
import com.udacity.webcrawler.json.ConfigurationLoader;
import com.udacity.webcrawler.json.CrawlResult;
import com.udacity.webcrawler.json.CrawlResultWriter;
import com.udacity.webcrawler.json.CrawlerConfiguration;
import com.udacity.webcrawler.profiler.Profiler;
import com.udacity.webcrawler.profiler.ProfilerModule;

import javax.inject.Inject;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.file.Path;
import java.util.Objects;

public final class WebCrawlerMain {

    private final CrawlerConfiguration config;

    private WebCrawlerMain(CrawlerConfiguration config) {
        this.config = Objects.requireNonNull(config);
    }

    @Inject
    private WebCrawler crawler;

    @Inject
    private Profiler profiler;

    private void run() throws Exception {
        // Inject dependencies using Guice
        Guice.createInjector(new WebCrawlerModule(config), new ProfilerModule()).injectMembers(this);

        // Crawl starting pages
        CrawlResult result = crawler.crawl(config.getStartPages());
        CrawlResultWriter resultWriter = new CrawlResultWriter(result);

        // TODO: Write the crawl results to a JSON file (or System.out if the file name is empty)
        String resultPath = config.getResultPath();
        if (resultPath != null && !resultPath.isEmpty()) {
            // Own logic: write to file
            resultWriter.write(Path.of(resultPath));
        } else {
            // Own logic: write to System.out
            try (Writer writer = new OutputStreamWriter(System.out)) {
                resultWriter.write(writer);
                writer.flush(); // ensure all output is printed
            } catch (Exception e) {
                System.err.println("Failed to write crawl result to System.out: " + e.getMessage());
            }
        }

        // TODO: Write the profile data to a text file (or System.out if the file name is empty)
        // Leave as-is for now
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            System.out.println("Usage: WebCrawlerMain [starting-url]");
            return;
        }

        // Load configuration
        CrawlerConfiguration config = new ConfigurationLoader(Path.of(args[0])).load();
        new WebCrawlerMain(config).run();
    }
}
