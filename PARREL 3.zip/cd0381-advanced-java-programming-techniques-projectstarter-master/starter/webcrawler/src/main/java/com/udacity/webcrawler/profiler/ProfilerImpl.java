package com.udacity.webcrawler.profiler;

import javax.inject.Inject;
import java.io.IOException;
import java.io.Writer;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Clock;
import java.time.ZonedDateTime;
import java.util.Objects;

import static java.time.format.DateTimeFormatter.RFC_1123_DATE_TIME;

/**
 * Implementation of the {@link Profiler} interface with minor customizations.
 */
final class ProfilerImpl implements Profiler {

    private final Clock clock;
    private final ProfilingState profilingState = new ProfilingState();
    private final ZonedDateTime startTimestamp;

    @Inject
    ProfilerImpl(Clock clock) {
        this.clock = Objects.requireNonNull(clock);
        this.startTimestamp = ZonedDateTime.now(clock);
    }

    @Override
    public <T> T wrap(Class<T> interfaceType, T delegate) {
        Objects.requireNonNull(interfaceType);

        // Ensure that the class is an interface
        if (!interfaceType.isInterface()) {
            throw new IllegalArgumentException("Only interfaces can be wrapped.");
        }

        // Check for at least one @Profiled method using streams
        boolean hasProfiled = java.util.Arrays.stream(interfaceType.getMethods())
                .anyMatch(m -> m.isAnnotationPresent(Profiled.class));

        if (!hasProfiled) {
            throw new IllegalArgumentException(
                    "Interface " + interfaceType.getName() + " does not have any @Profiled methods."
            );
        }

        // Create the dynamic proxy using a slightly different variable naming
        Object proxyInstance = Proxy.newProxyInstance(
                interfaceType.getClassLoader(),
                new Class<?>[]{interfaceType},
                new ProfilingMethodInterceptor(clock, profilingState, delegate)
        );

        return interfaceType.cast(proxyInstance);
    }

    @Override
    public void writeData(Path path) {
        Objects.requireNonNull(path);

        try (Writer writer = Files.newBufferedWriter(path,
                java.nio.file.StandardOpenOption.CREATE,
                java.nio.file.StandardOpenOption.APPEND)) {
            writeData(writer);
        } catch (IOException ex) {
            throw new RuntimeException("Unable to write profiling output", ex);
        }
    }

    @Override
    public void writeData(Writer writer) throws IOException {
        writer.write("Run at " + RFC_1123_DATE_TIME.format(startTimestamp));
        writer.write(System.lineSeparator());
        profilingState.write(writer);
        writer.write(System.lineSeparator());
    }
}
