package com.udacity.webcrawler.profiler;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.Objects;

/**
 * Intercepts method calls and records execution time if the method is annotated with {@link Profiled}.
 */
final class ProfilingMethodInterceptor implements InvocationHandler {

    private final Clock clock;
    private final ProfilingState profilingState;
    private final Object targetObject;

    ProfilingMethodInterceptor(Clock clock, ProfilingState profilingState, Object targetObject) {
        this.clock = Objects.requireNonNull(clock, "Clock cannot be null");
        this.profilingState = Objects.requireNonNull(profilingState, "ProfilingState cannot be null");
        this.targetObject = Objects.requireNonNull(targetObject, "Target object cannot be null");
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        boolean isProfiled = method.isAnnotationPresent(Profiled.class);

        Instant startTime = null;
        if (isProfiled) {
            startTime = clock.instant();
        }

        Object result;
        try {
            result = method.invoke(targetObject, args);
        } catch (InvocationTargetException e) {
            // Unwrap the original exception
            throw e.getCause();
        } finally {
            if (isProfiled && startTime != null) {
                Instant endTime = clock.instant();
                Duration duration = Duration.between(startTime, endTime);
                profilingState.record(targetObject.getClass(), method, duration);
            }
        }

        return result;
    }
}
